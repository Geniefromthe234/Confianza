import { useEffect, useState, useCallback } from 'react';

export function useActiveSection(sectionIds: string[]) {
  const [activeSection, setActiveSection] = useState<string>('home');

  useEffect(() => {
    let mostVisible: { id: string; ratio: number } | null = null;

    const observer = new IntersectionObserver((entries) => {
      entries.forEach((entry) => {
        const target = entry.target as HTMLElement;
        if (entry.isIntersecting && entry.intersectionRatio && entry.intersectionRatio > 0 && target.id) {
          if (!mostVisible || entry.intersectionRatio > mostVisible.ratio) {
            mostVisible = { id: target.id, ratio: entry.intersectionRatio };
          }
        }
      });

      if (mostVisible) {
        setActiveSection(mostVisible.id);
      }
    }, {
      threshold: [0.1, 0.3],
      rootMargin: '-120px 0px -25% 0px'
    });

    // Initial active
    setActiveSection(sectionIds[0] || '');

    sectionIds.forEach((id) => {
      const element = document.getElementById(id);
      if (element) {
        observer.observe(element);
      }
    });

    return () => observer.disconnect();
  }, [sectionIds]);

  return activeSection;
}
